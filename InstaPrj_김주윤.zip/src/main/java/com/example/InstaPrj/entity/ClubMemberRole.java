package com.example.InstaPrj.entity;

public enum ClubMemberRole {
  // 권한은 USER, MANAGER, ADMIN으로 나뉘지만 이 모두는 Member 엔티티에 속함.
  USER, MANAGER, ADMIN
}
