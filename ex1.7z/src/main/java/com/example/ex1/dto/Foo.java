package com.example.ex1.dto;

import lombok.*;

@Data
//@Setter
//@Getter
//@NoArgsConstructor
//@ToString
public class Foo {
  private String favorite;
  private int legs;
}
