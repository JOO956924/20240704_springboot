package com.example.ex1.controller;

import com.example.ex1.dto.Foo;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/data")
public class DataController {
  // view를 위한 라이브러리가 추가 되어 있지 않는 경우는 static활용
  @GetMapping("/foo")
  public String getFoo() {
    return new Foo().toString();
  }
}
